package bo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.FloatBuffer;
import java.util.ArrayList;

import bean.Giangvienbean;
import bean.Nguoibean;
import bean.Nhanvienbean;
import dao.Nguoidao;

public class Nguoibo {
	Nguoidao ndao = new Nguoidao();
	ArrayList<Nguoibean> ds;
	public ArrayList<Nguoibean> getds() throws Exception{
		ds = ndao.getds();
		return ds;
	}
	public void hienthi() throws Exception {
		for(Nguoibean n:ds) {
			System.out.print(n.toString()+"\n");
		}
	}
	public void LuuKQ() throws Exception{
		try {
			FileWriter fw = new FileWriter("ketqua.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			for(Nguoibean n:ds) {
				bw.write(n.toString()+ "\n");
				
			}bw.close();		
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	ArrayList<Nguoibean> dsach = new ArrayList<Nguoibean>();
	public void C3() throws Exception {
		try {
			BufferedReader br = new BufferedReader(new FileReader("ketqua.txt"));
			String line;
			while((line = br.readLine()) != null) {
				String[] ds = line.split(",");
				if(ds.length == 4) {
					Nhanvienbean nv = new Nhanvienbean(ds[0], ds[1], ds[2], Double.parseDouble(ds[3]));
					dsach.add(nv);
				}
				if(ds.length == 5) {
					Giangvienbean gv = new Giangvienbean(ds[0], ds[1], ds[2], Double.parseDouble(ds[3]), Double.parseDouble(ds[4]));
					dsach.add(gv);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("/Danh sach nhan vien");
			for(Nguoibean n:getds()){
				if(n instanceof Nhanvienbean) {
					System.out.println(n.toString());
				}		
			}
			System.out.println("/Danh sach giang vien");
			for(Nguoibean n:getds()){
				if(n instanceof Giangvienbean) {
					System.out.println(n.toString());
				}		
			}
		}
	public void docfile() throws Exception {
		try {
			BufferedReader br = new BufferedReader(new FileReader("ketqua.txt"));
			String line;
			while((line = br.readLine()) != null) {
				String[] ds = line.split(",");
				String ma_nv = ds[0];
				String ho_ten = ds[1];
				String loaihd = ds[2];
				
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	
	}
}
		

		
						
		



