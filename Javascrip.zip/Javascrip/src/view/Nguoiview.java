package view;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import bean.Nguoibean;
import bo.Nguoibo;
import dao.Ketnoidao;

public class Nguoiview {
	public static void main(String[] args) {
		try {
			Nguoibo nb = new Nguoibo();
			ArrayList<Nguoibean> ds = nb.getds();
			System.out.println("Danh sach: ");
			nb.hienthi();
			nb.LuuKQ();
			nb.C3();
			
			Ketnoidao kn = new Ketnoidao();
			kn.ketnoi();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
}
