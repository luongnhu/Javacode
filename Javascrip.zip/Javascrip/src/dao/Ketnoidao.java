package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Ketnoidao {
	public static Connection cn;
	public void ketnoi() throws Exception {
		//b1: Xac dinh HQTCSDL
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		System.out.println("Đã xác định HQTCSDL");
		
		cn = DriverManager.getConnection("jdbc:sqlserver://LAPTOP-95CI4T0G\\SQLEXPRESS:1433;databaseName=Ontap;user=sa;password=123");
		System.out.println("Đã kết nối");
		System.out.println("---------------");
	}	

			public static void main(String[] args) {
				try {
					Ketnoidao kn = new Ketnoidao();
					kn.ketnoi();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
}
