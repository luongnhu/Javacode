package dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import bean.Giangvienbean;
import bean.Nguoibean;
import bean.Nhanvienbean;

public class Nguoidao {
	public ArrayList<Nguoibean> getds() throws Exception {
		ArrayList<Nguoibean> List = new ArrayList<Nguoibean>();
		try {
			FileReader fr = new FileReader("ds.txt");
			BufferedReader r = new BufferedReader(fr);
			while(true) {
				String s = r.readLine();
				if (s == null || s == "") break;
				String[] ds = s.split("[,]");
				if(ds.length == 4) {
					Nhanvienbean nv = new Nhanvienbean(ds[0], ds[1], ds[2], Double.parseDouble(ds[3]));
					List.add(nv);
				}
				if(ds.length == 5) {
					Giangvienbean gv = new Giangvienbean(ds[0], ds[1], ds[2], Double.parseDouble(ds[3]), Double.parseDouble(ds[4]));
					List.add(gv);
				}
			} r.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return List;
	}
	
	
	
	
	public ArrayList<Nhanvienbean> getnv() throws Exception{
		ArrayList<Nhanvienbean> tam = new ArrayList<Nhanvienbean>();
		for(Nguoibean n:getds()){
			if(n instanceof Nhanvienbean) {
				tam.add((Nhanvienbean)n);
			}		
		}return tam;
	}
	
//	
//	
	public ArrayList<Giangvienbean> getgv() throws Exception{
		ArrayList<Giangvienbean> tam = new ArrayList<Giangvienbean>();
		for(Nguoibean n:getds()){
			if(n instanceof Giangvienbean) {
				tam.add((Giangvienbean)n);
			}		
		}return tam;
		
	}
}
