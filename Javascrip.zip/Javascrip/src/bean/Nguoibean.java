package bean;

public class Nguoibean {

	private String ho_ten;
	
	public Nguoibean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Nguoibean(String ho_ten) {
		super();
		this.ho_ten = ho_ten;
	}
	public String getHo_ten() {
		return ho_ten;
	}
	public void setHo_ten(String ho_ten) {
		this.ho_ten = ho_ten;
	}
	@Override
	public String toString() {
		return ho_ten ;
	}	
}
