package bean;

public class Nhanvienbean extends Nguoibean {
	private String ma_nv;
	private String loaihd;
	private double hsl;
	
	
	
	public Nhanvienbean() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Nhanvienbean(String ma_nv, String ho_ten,  String loaihd, double hsl) {
		super(ho_ten);
		this.ma_nv = ma_nv;
		this.loaihd = loaihd;
		this.hsl = hsl;
	}

	public String getMa_nv() {
		return ma_nv;
	}


	public void setMa_nv(String ma_nv) {
		this.ma_nv = ma_nv;
	}


	public String getLoaihd() {
		return loaihd;
	}


	public void setLoaihd(String loaihd) {
		this.loaihd = loaihd;
	}


	public Double getHsl() {
		return hsl;
	}


	public void setHsl(Double hsl) {
		this.hsl = hsl;
	}


	@Override
	public String toString() {
		return  ma_nv + ";" + super.toString()+ ";" +  loaihd  +";" + hsl;
	}
}
