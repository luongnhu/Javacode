package bean;

public class Giangvienbean extends Nguoibean {

	private String ma_gv;
	private String loaihd;
	private double hsl;
	private double phucap;
	public Giangvienbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Giangvienbean(String ma_gv, String ho_ten,  String loaihd, double hsl, double phucap) {
		super(ho_ten);
		this.ma_gv = ma_gv;
		this.loaihd = loaihd;
		this.hsl = hsl;
		this.phucap = phucap;
	}

	
	public String getMa_gv() {
		return ma_gv;
	}


	public void setMa_gv(String ma_gv) {
		this.ma_gv = ma_gv;
	}


	public String getLoaihd() {
		return loaihd;
	}


	public void setLoaihd(String loaihd) {
		this.loaihd = loaihd;
	}


	public double getHsl() {
		return hsl;
	}


	public void setHsl(double hsl) {
		this.hsl = hsl;
	}


	public double getPhucap() {
		return phucap;
	}


	public void setPhucap(double phucap) {
		this.phucap = phucap;
	}	
	

	@Override
	public String toString() {
		return  ma_gv + ";" + super.toString()+ ";" + loaihd + ";"  + hsl + ";" + phucap  ;
	}
	
	
}
