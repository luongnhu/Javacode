package bo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import bean.KHDienthoaibean;
import bean.KHInternetbean;
import bean.Nguoibean;
import dao.Nguoidao;

public class Nguoibo {
	Nguoidao ndao = new Nguoidao();
	ArrayList<Nguoibean> ds;
	public ArrayList<Nguoibean> getds() throws Exception{
		ds = ndao.getds();
		return ds;
	}
	public void hienthi() throws Exception{
		for(Nguoibean n:ds) {
			System.out.println(n.toString()+ "\n");
		}
	}
	ArrayList<Nguoibean> dsach = new ArrayList<Nguoibean>();
	public void c2() throws Exception{
		try {
			FileReader fr = new FileReader("Khachhang.txt");
			BufferedReader br = new BufferedReader(fr);
			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/YYYY");
			String line;
			while((line = br.readLine()) != null) {
			
			String[] ds = line.split(",");
			if (ds.length == 6 && ds[0].equals("IN")){
				KHInternetbean it = new KHInternetbean(ds[0], ds[1], ds[2], ds[3], dd.parse(ds[4]),ds[5]);
				dsach.add(it);
			}
			if (ds.length == 6 && ds[0].equals("DT")) {
				KHDienthoaibean dt = new KHDienthoaibean(ds[0], ds[1], ds[2], ds[3], dd.parse(ds[4]),ds[5]);
				dsach.add(dt);
			}
			}
			System.out.println("/Danh sach KH it");
			for(Nguoibean n:dsach){
				if(n instanceof KHInternetbean) {
					System.out.println(n.toString());
				}		
			}
			System.out.println("/Danh sach KH dt");
			for(Nguoibean n:dsach){
				if(n instanceof KHDienthoaibean) {
					System.out.println(n.toString());
				}		
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
