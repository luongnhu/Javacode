package bean;

import java.util.Date;

public class KHDienthoaibean extends Nguoibean {
private String Loaisim;

	

	

	public KHDienthoaibean() {
	super();
	// TODO Auto-generated constructor stub
}



	public KHDienthoaibean(String madv, String tendv, String hoten, String makh, Date ngaydki, String loaisim) {
		super(madv, tendv, hoten, makh, ngaydki);
		Loaisim = loaisim;
	}



	public KHDienthoaibean(String madv, String tendv, String hoten, String makh, Date ngaydki) {
		super(madv, tendv, hoten, makh, ngaydki);
		// TODO Auto-generated constructor stub
	}



	public String getLoaisim() {
		return Loaisim;
	}

	public void setLoaisim(String loaisim) {
		Loaisim = loaisim;
	}

	@Override
	public String toString() {
		return super.toString()+"," + Loaisim ;
	}
}

