package bean;

import java.util.Date;

public class KHInternetbean extends Nguoibean{
	
	private String Bangthong;

	
	
	

	public KHInternetbean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KHInternetbean(String madv, String tendv, String hoten, String makh, Date ngaydki) {
		super(madv, tendv, hoten, makh, ngaydki);
		// TODO Auto-generated constructor stub
	}
	

	public KHInternetbean(String madv, String tendv, String hoten, String makh, Date ngaydki, String bangthong) {
		super(madv, tendv, hoten, makh, ngaydki);
		Bangthong = bangthong;
	}

	public String getBangthong() {
		return Bangthong;
	}

	public void setBangthong(String bangthong) {
		Bangthong = bangthong;
	}

	@Override
	public String toString() {
		return super.toString()+ ","+ Bangthong ;
	}
	
	
	
}
