package bean;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Nguoibean {
	private String Madv;
	private String Tendv;
	private String Hoten;
	private String Makh;
	private Date Ngaydki;

	public Nguoibean(String madv, String tendv, String hoten, String makh, Date ngaydki) {
		super();
		Madv = madv;
		Tendv = tendv;
		Hoten = hoten;
		Makh = makh;
		Ngaydki = ngaydki;
	}
	public Nguoibean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMadv() {
		return Madv;
	}
	public void setMadv(String madv) {
		Madv = madv;
	}
	public String getTendv() {
		return Tendv;
	}
	public void setTendv(String tendv) {
		Tendv = tendv;
	}
	public String getHoten() {
		return Hoten;
	}
	public void setHoten(String hoten) {
		Hoten = hoten;
	}
	public String getMakh() {
		return Makh;
	}
	public void setMakh(String makh) {
		Makh = makh;
	}
	public Date getNgaydki() {
		return Ngaydki;
	}


	public void setNgaydki(Date ngaydki) {
		Ngaydki = ngaydki;
	}


	@Override
	public String toString() {
		SimpleDateFormat dd= new SimpleDateFormat("dd/MM/YYYY");
		return   Madv + "," + Tendv + "," + Hoten + "," + Makh + ","+ dd.format(Ngaydki) ;
	}
	
	
	

}
