package view;

import java.util.ArrayList;

import bean.Nguoibean;
import bo.Nguoibo;
import dao.Ketnoidao;

public class Nguoiview {
	public static void main(String[] args) {
		try {
			Nguoibo nb = new Nguoibo();
			ArrayList<Nguoibean> ds = nb.getds();
			System.out.println("Danh sach");
			nb.hienthi();
			nb.c2();
			
			Ketnoidao kn = new Ketnoidao();
			kn.Ketnoi();
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}}
