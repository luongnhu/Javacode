package dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import bean.KHDienthoaibean;
import bean.KHInternetbean;
import bean.Nguoibean;

public class Nguoidao {
	public ArrayList<Nguoibean> getds() throws Exception{
		ArrayList<Nguoibean> List = new ArrayList<Nguoibean>();
		SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");		
		try {
			FileReader fr = new FileReader("Khachhang.txt");
			BufferedReader r = new BufferedReader(fr);
			while(true) {
				String s = r.readLine();
				if(s == null || s=="") break;
				String[] ds = s.split("[,]");
				if (ds.length == 6 && ds[0].equals("IN")){
					KHInternetbean it = new KHInternetbean(ds[0], ds[1], ds[2], ds[3], dd.parse(ds[4]),ds[5]);
					List.add(it);
				}
				if (ds.length == 6 && ds[0].equals("DT")) {
					KHDienthoaibean dt = new KHDienthoaibean(ds[0], ds[1], ds[2], ds[3], dd.parse(ds[4]),ds[5]);
					List.add(dt);
				}

			}r.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return List;
	}
}
